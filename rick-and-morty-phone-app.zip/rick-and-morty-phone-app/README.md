# rick-and-morty-phone-app
It's an application where I use a public API (Rick and Morty Api).
It's an application where I use a public API (Rick and Morty Api), anyway before in my projects I made a similar application but this is a web application. 
With this application I want to practice my studies at platzi academy in the Clean Architecture and Desingner Patterns courses.
